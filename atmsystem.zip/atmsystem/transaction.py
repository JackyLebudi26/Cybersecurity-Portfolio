"""
Transaction module for ATM system.
Handles deposits, withdrawals, transfers, and logs.
"""

import csv
import itertools
import os
from datetime import datetime


class TransactionService:
    """
    Handles all banking transactions.
    """

    TRANSACTION_FILE = "transactions.txt"
    LOG_FILE = "log.txt"

    def __init__(self):
        self.ensure_files_exist()

    def ensure_files_exist(self):
        """
        Create transaction and log files if missing.
        """

        if not os.path.exists(self.TRANSACTION_FILE):
            with open(self.TRANSACTION_FILE, "w", newline="") as file:
                writer = csv.writer(file)

                writer.writerow([
                    "timestamp",
                    "phone",
                    "type",
                    "amount",
                    "balance_after"
                ])

        if not os.path.exists(self.LOG_FILE):
            with open(self.LOG_FILE, "w", newline="") as file:
                writer = csv.writer(file)

                writer.writerow([
                    "timestamp",
                    "phone",
                    "event"
                ])

    def get_timestamp(self):
        """
        Return current date and time.
        """
        return datetime.now().strftime(
            "%Y-%m-%d %H:%M:%S"
        )

    def log_event(self, phone, event):
        """
        Save event to log file.
        """
        with open(self.LOG_FILE, "a", newline="") as file:
            writer = csv.writer(file)

            writer.writerow([
                self.get_timestamp(),
                phone,
                event
            ])

    def record_transaction(
        self,
        phone,
        transaction_type,
        amount,
        balance
    ):
        """
        Save transaction to file.
        """
        with open(
            self.TRANSACTION_FILE,
            "a",
            newline=""
        ) as file:

            writer = csv.writer(file)

            writer.writerow([
                self.get_timestamp(),
                phone,
                transaction_type,
                amount,
                balance
            ])

    def deposit(self, account, amount):
        """
        Deposit money into account.
        """
        account.balance += amount

        self.record_transaction(
            account.phone,
            "DEPOSIT",
            amount,
            account.balance
        )

    def withdraw(self, account, amount):
        """
        Withdraw money from account.
        """
        if amount > account.balance:
            print("Insufficient funds.")
            return False

        account.balance -= amount

        self.record_transaction(
            account.phone,
            "WITHDRAW",
            amount,
            account.balance
        )

        return True

    def transfer(
        self,
        sender,
        receiver,
        amount
    ):
        """
        Transfer money between accounts.
        """

        if sender.account_number == receiver.account_number:
            print("Cannot transfer to your own account.")
            return False

        if amount <= 0:
            print("Invalid amount.")
            return False

        if amount > sender.balance:
            print("Insufficient funds.")
            return False

        sender.balance -= amount
        receiver.balance += amount

        self.record_transaction(
            sender.phone,
            "EFT OUT",
            amount,
            sender.balance
        )

        self.record_transaction(
            receiver.phone,
            "EFT IN",
            amount,
            receiver.balance
        )

        return True

    def show_statement(self, phone):
        """
        Display account statement.
        """

        transactions_found = False

        with open(self.TRANSACTION_FILE, "r", newline="") as file:
            reader = csv.reader(file)
            rows = list(reader)

        if not rows:
            print("\nNo transactions available.")
            return

        # Detect headers if present.
        if rows[0] == [
            "timestamp",
            "phone",
            "type",
            "amount",
            "balance_after",
        ]:
            rows = rows[1:]

        print("\n===== ACCOUNT STATEMENT =====")

        for row in rows:
            if len(row) < 5:
                continue

            timestamp, row_phone, txn_type, amount, balance_after = row

            if row_phone == phone:
                transactions_found = True
                print(
                    f"{timestamp} | {txn_type} | "
                    f"R{float(amount):.2f} | Balance: "
                    f"R{float(balance_after):.2f}"
                )

        if not transactions_found:
            print("No statement entries found for this account.")
