"""
Main ATM system program.
"""

from account import AccountRepository
from transaction import TransactionService


account_repo = AccountRepository()

transaction_service = TransactionService()


def register():
    """
    Register new user.
    """

    print("\n===== REGISTER =====")

    phone = input(
        "Enter 10-digit phone number: "
    )

    if not phone.isdigit() or len(phone) != 10:
        print("Invalid phone number.")
        return

    pin = input(
        "Enter 4-digit PIN: "
    )

    if not pin.isdigit() or len(pin) not in [4, 5]:
        print("Invalid PIN.")
        return

    confirm_pin = input(
        "Confirm PIN: "
    )

    if pin != confirm_pin:
        print("PINs do not match.")
        return

    account = account_repo.register_account(
        phone,
        pin
    )

    if account:
        transaction_service.log_event(
            phone,
            "REGISTERED"
        )

        print("\nAccount created successfully.")

        print(
            f"Your account number is: "
            f"{account.account_number}"
        )


def login():
    """
    Login existing user.
    """

    print("\n===== LOGIN =====")

    attempts = 0

    while attempts < 3:

        phone = input("Phone number: ")

        pin = input("PIN: ")

        account = account_repo.find_by_phone(phone)

        if account and account.verify_pin(pin):

            transaction_service.log_event(
                phone,
                "LOGINSUCCESS"
            )

            print("\nLogin successful.")

            transaction_menu(account)

            return

        else:
            attempts += 1

            transaction_service.log_event(
                phone,
                "LOGINFAILED"
            )

            print("Invalid credentials.")

    print("Too many failed attempts.")


def transaction_menu(account):
    """
    Display transaction menu.
    """

    while True:

        print("\n===== ATM MENU =====")

        print("1. Deposit")
        print("2. Withdraw")
        print("3. Transfer (EFT)")
        print("4. View Statement")
        print("5. View Balance")
        print("6. Logout")

        choice = input("Choose option: ")

        if choice == "1":

            amount = float(
                input("Enter amount: ")
            )

            if amount <= 0:
                print("Invalid amount.")
                continue

            transaction_service.deposit(
                account,
                amount
            )

            account_repo.update_account(account)

            print("Deposit successful.")

        elif choice == "2":

            amount = float(
                input("Enter amount: ")
            )

            if amount <= 0:
                print("Invalid amount.")
                continue

            success = transaction_service.withdraw(
                account,
                amount
            )

            if success:
                account_repo.update_account(account)

                print("Withdrawal successful.")

        elif choice == "3":

            receiver_account_number = input(
                "Receiver account number: "
            )

            receiver = (
                account_repo.find_by_account_number(
                    receiver_account_number
                )
            )

            if not receiver:
                print("Account not found.")
                continue

            amount = float(
                input("Enter amount: ")
            )

            success = transaction_service.transfer(
                account,
                receiver,
                amount
            )

            if success:

                account_repo.update_account(account)

                account_repo.update_account(receiver)

                print("Transfer successful.")

        elif choice == "4":

            transaction_service.show_statement(
                account.phone
            )

        elif choice == "5":

            print(
                f"Current balance: "
                f"R{account.balance:.2f}"
            )

        elif choice == "6":

            print("Logging out...")
            break

        else:
            print("Invalid option.")


def main():
    """
    Main menu loop.
    """

    while True:

        print("\n===== ATM SYSTEM =====")

        print("1. Register")
        print("2. Login")
        print("3. Exit")

        choice = input("Choose option: ")

        if choice == "1":
            register()

        elif choice == "2":
            login()

        elif choice == "3":
            print("Goodbye.")
            break

        else:
            print("Invalid option.")


main()
