"""
Account management module for ATM system.
Handles registration, login, hashing, and account storage.
"""

import csv
import hashlib
import os
import random
import string


class Account:
    """
    Represents a bank account.
    """

    def __init__(self, account_number, phone, pin_hash, balance):
        self.account_number = account_number
        self.phone = phone
        self.pin_hash = pin_hash
        self.balance = float(balance)

    def verify_pin(self, pin):
        """
        Verify entered PIN against stored hash.
        """
        hashed_pin = hashlib.sha256(bytes(pin, "utf-8")).hexdigest()
        return hashed_pin == self.pin_hash


class AccountRepository:
    """
    Handles reading and writing account data.
    """

    FILE_NAME = "accountbalances.txt"

    def __init__(self):
        self.ensure_file_exists()

    def ensure_file_exists(self):
        """
        Create file with headers if it does not exist.
        """
        if not os.path.exists(self.FILE_NAME):
            with open(self.FILE_NAME, "w", newline="") as file:
                writer = csv.writer(file)

                writer.writerow([
                    "account_number",
                    "phone",
                    "pin_hash",
                    "balance"
                ])

    def hash_pin(self, pin):
        """
        Hash PIN using SHA-256.
        """
        return hashlib.sha256(bytes(pin, "utf-8")).hexdigest()

    def generate_account_number(self):
        """
        Generate unique 8-digit account number.
        """
        while True:
            number = "".join(
                random.choices(string.digits, k=8)
            )

            if not self.find_by_account_number(number):
                return number

    def load_accounts(self):
        """
        Load all accounts from file.
        """
        accounts = []

        with open(self.FILE_NAME, "r") as file:
            reader = csv.DictReader(file)

            for row in reader:
                account = Account(
                    row["account_number"],
                    row["phone"],
                    row["pin_hash"],
                    row["balance"]
                )

                accounts.append(account)

        return accounts

    def save_accounts(self, accounts):
        """
        Save all accounts back to file.
        """
        with open(self.FILE_NAME, "w", newline="") as file:
            writer = csv.writer(file)

            writer.writerow([
                "account_number",
                "phone",
                "pin_hash",
                "balance"
            ])

            for account in accounts:
                writer.writerow([
                    account.account_number,
                    account.phone,
                    account.pin_hash,
                    account.balance
                ])

    def find_by_phone(self, phone):
        """
        Find account using phone number.
        """
        accounts = self.load_accounts()

        for account in accounts:
            if account.phone == phone:
                return account

        return None

    def find_by_account_number(self, account_number):
        """
        Find account using account number.
        """
        accounts = self.load_accounts()

        for account in accounts:
            if account.account_number == account_number:
                return account

        return None

    def register_account(self, phone, pin):
        """
        Create new account.
        """
        if self.find_by_phone(phone):
            print("Phone number already exists.")
            return None

        account_number = self.generate_account_number()

        pin_hash = self.hash_pin(pin)

        new_account = Account(
            account_number,
            phone,
            pin_hash,
            0.0
        )

        accounts = self.load_accounts()

        accounts.append(new_account)

        self.save_accounts(accounts)

        return new_account

    def update_account(self, updated_account):
        """
        Update account balance.
        """
        accounts = self.load_accounts()

        for account in accounts:
            if account.account_number == updated_account.account_number:
                account.balance = updated_account.balance

        self.save_accounts(accounts)
